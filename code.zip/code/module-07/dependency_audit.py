#!/usr/bin/env python3
"""
Dependency Confusion Auditor - Educational / Defensive Tool
============================================================

PURPOSE:
    Check whether internal/private package names also exist on public registries
    (PyPI, npm). If a public package shares the same name as an internal one,
    the organization may be vulnerable to a dependency confusion attack, where
    a malicious public package is installed instead of the private one.

    Reference: Alex Birsan's "Dependency Confusion" research (2021).
    MITRE ATT&CK: T1195.002 (Supply Chain Compromise - Software Supply Chain)

USAGE:
    ISOLATED LAB ENVIRONMENTS ONLY - Authorized security testing.
    python3 dependency_audit.py --packages packages.txt
    python3 dependency_audit.py --demo

    packages.txt format (one package per line):
        internal-auth-lib
        corp-logging-utils
        acme-data-pipeline

NOTE:
    This tool makes HTTP requests to public registries (pypi.org, registry.npmjs.org).
    It does NOT install anything. Read-only queries only.
"""

import argparse
import json
import sys
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
PYPI_URL = "https://pypi.org/pypi/{package}/json"
NPM_URL = "https://registry.npmjs.org/{package}"
REQUEST_TIMEOUT = 10      # seconds
RATE_LIMIT_DELAY = 0.5    # seconds between requests (be polite)

# Demo package list -- these are fictitious names for lab demonstration.
DEMO_PACKAGES = [
    "acme-internal-auth",
    "corp-secret-utils",
    "requests",             # Real public package (should be found)
    "express",              # Real public npm package (should be found)
    "acme-data-pipeline",
]


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------
@dataclass
class AuditResult:
    """Result of checking one package against a single registry."""
    package_name: str
    registry: str               # "pypi" or "npm"
    exists_publicly: bool
    public_version: Optional[str] = None
    description: Optional[str] = None
    risk_level: str = "NONE"

    def __str__(self) -> str:
        status = "FOUND" if self.exists_publicly else "not found"
        ver = f" (v{self.public_version})" if self.public_version else ""
        return f"  [{self.risk_level:^8}] {self.registry:>5}: {status}{ver}"


# ---------------------------------------------------------------------------
# Registry Queries
# ---------------------------------------------------------------------------
def check_pypi(package_name: str) -> AuditResult:
    """Query PyPI to see if a package with this name exists publicly."""
    url = PYPI_URL.format(package=package_name)
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode())
            version = data.get("info", {}).get("version", "unknown")
            summary = data.get("info", {}).get("summary", "")[:80]
            return AuditResult(
                package_name=package_name,
                registry="pypi",
                exists_publicly=True,
                public_version=version,
                description=summary,
                risk_level="HIGH",
            )
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return AuditResult(package_name=package_name, registry="pypi",
                               exists_publicly=False)
        return AuditResult(package_name=package_name, registry="pypi",
                           exists_publicly=False, description=f"HTTP {exc.code}")
    except Exception as exc:
        return AuditResult(package_name=package_name, registry="pypi",
                           exists_publicly=False, description=str(exc)[:60])


def check_npm(package_name: str) -> AuditResult:
    """Query npm registry to see if a package with this name exists publicly."""
    url = NPM_URL.format(package=package_name)
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode())
            version = data.get("dist-tags", {}).get("latest", "unknown")
            description = data.get("description", "")[:80]
            return AuditResult(
                package_name=package_name,
                registry="npm",
                exists_publicly=True,
                public_version=version,
                description=description,
                risk_level="HIGH",
            )
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return AuditResult(package_name=package_name, registry="npm",
                               exists_publicly=False)
        return AuditResult(package_name=package_name, registry="npm",
                           exists_publicly=False, description=f"HTTP {exc.code}")
    except Exception as exc:
        return AuditResult(package_name=package_name, registry="npm",
                           exists_publicly=False, description=str(exc)[:60])


# ---------------------------------------------------------------------------
# Audit Engine
# ---------------------------------------------------------------------------
def audit_package(package_name: str) -> list[AuditResult]:
    """Check a single package name against all supported registries."""
    results = []
    results.append(check_pypi(package_name))
    time.sleep(RATE_LIMIT_DELAY)
    results.append(check_npm(package_name))
    time.sleep(RATE_LIMIT_DELAY)
    return results


def load_packages(path: str) -> list[str]:
    """Load package names from a text file (one per line)."""
    packages = []
    with open(path, "r") as fh:
        for line in fh:
            name = line.strip()
            if name and not name.startswith("#"):
                packages.append(name)
    return packages


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Dependency Confusion Auditor - check internal package names "
                    "against public registries."
    )
    parser.add_argument("--packages", help="Path to file with package names")
    parser.add_argument("--demo", action="store_true",
                        help="Run with demo package list")
    args = parser.parse_args()

    if not args.packages and not args.demo:
        parser.print_help()
        sys.exit(1)

    packages = DEMO_PACKAGES if args.demo else load_packages(args.packages)

    print(f"[*] Dependency Confusion Auditor")
    print(f"[*] Checking {len(packages)} package(s) against PyPI and npm\n")

    all_results: list[AuditResult] = []
    for pkg in packages:
        print(f"  Checking: {pkg}")
        results = audit_package(pkg)
        all_results.extend(results)
        for r in results:
            print(r)
        print()

    # Summary
    risks = [r for r in all_results if r.exists_publicly]
    print("=" * 60)
    if risks:
        print(f"[!] {len(risks)} PUBLIC MATCH(ES) FOUND - potential confusion risk:\n")
        for r in risks:
            print(f"    {r.package_name} on {r.registry} "
                  f"(v{r.public_version}) - {r.description}")
        print(f"\n[*] RECOMMENDATION: Pin internal registries explicitly and use")
        print(f"    scoped namespaces (e.g., @corp/package for npm, or private")
        print(f"    PyPI index with --index-url and --extra-index-url precedence).")
    else:
        print("[*] No public matches found. Risk appears low.")


if __name__ == "__main__":
    main()
