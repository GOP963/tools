<#
.SYNOPSIS
    DLL Sideload Candidate Finder - Educational / Defensive Tool

.DESCRIPTION
    Scans running processes to identify potential DLL sideloading opportunities.
    DLL sideloading occurs when an application loads a DLL from its own directory
    (or another attacker-controllable path) instead of the intended system DLL.

    This tool helps DEFENDERS audit their environment for applications that are
    vulnerable to DLL sideloading, so those risks can be mitigated before an
    adversary exploits them.

    Technique Reference: MITRE ATT&CK T1574.002 (DLL Side-Loading)

.NOTES
    ISOLATED LAB ENVIRONMENTS ONLY - Authorized security testing.
    Do NOT use against systems without explicit written authorization.

    Requires: PowerShell 5.1+, Administrator privileges recommended.
#>

[CmdletBinding()]
param(
    [string]$OutputPath = ".\sideload_candidates.csv",
    [switch]$Verbose
)

# ---- Configuration ---------------------------------------------------------
# Known DLLs that are commonly sideloaded by adversaries.
# Source: public threat intelligence reports and MITRE ATT&CK references.
$KnownSideloadTargets = @(
    "version.dll", "winhttp.dll", "dbghelp.dll", "dbgcore.dll",
    "wer.dll", "amsi.dll", "netapi32.dll", "crypt32.dll",
    "WINMM.dll", "msasn1.dll", "cryptsp.dll", "profapi.dll",
    "comctl32.dll", "msvcp140.dll", "vcruntime140.dll"
)

# Directories where a legitimate DLL should reside (System32, SysWOW64).
$SystemDirs = @(
    "$env:SystemRoot\System32",
    "$env:SystemRoot\SysWOW64"
)

# ---- Functions --------------------------------------------------------------
function Get-LoadedModules {
    <#
    .SYNOPSIS
        Enumerate loaded DLLs for each running process.
    #>
    param([System.Diagnostics.Process]$Process)

    try {
        # Modules property may throw Access Denied for protected processes.
        return $Process.Modules | ForEach-Object {
            [PSCustomObject]@{
                ModuleName = $_.ModuleName
                FileName   = $_.FileName
            }
        }
    } catch {
        if ($Verbose) {
            Write-Warning "Cannot inspect modules for PID $($Process.Id) ($($Process.ProcessName)): $_"
        }
        return @()
    }
}

function Test-SideloadCandidate {
    <#
    .SYNOPSIS
        Determine if a loaded DLL is a sideload candidate.
        A candidate is a DLL loaded from the application directory when a
        system copy also exists -- meaning an attacker could plant a malicious
        copy in the application directory to hijack execution.
    #>
    param(
        [string]$ModuleName,
        [string]$FullPath,
        [string]$ProcessDir
    )

    # Skip DLLs loaded from system directories (expected behavior).
    foreach ($sysDir in $SystemDirs) {
        if ($FullPath -like "$sysDir\*") { return $false }
    }

    # Check if a system-directory copy also exists (indicates search-order issue).
    $systemCopyExists = $SystemDirs | Where-Object { Test-Path (Join-Path $_ $ModuleName) }
    if (-not $systemCopyExists) { return $false }

    # If the DLL is loaded from the process's own directory AND a system
    # copy exists, it is a sideload candidate.
    $dllDir = Split-Path $FullPath -Parent
    return ($dllDir -eq $ProcessDir)
}

# ---- Main Scan --------------------------------------------------------------
Write-Host "[*] DLL Sideload Candidate Finder" -ForegroundColor Cyan
Write-Host "[*] Scanning running processes..." -ForegroundColor Cyan

$results = [System.Collections.Generic.List[PSObject]]::new()

$processes = Get-Process -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -and $_.Path -notlike "$env:SystemRoot\System32\*" }

foreach ($proc in $processes) {
    $procDir = Split-Path $proc.Path -Parent
    $modules = Get-LoadedModules -Process $proc

    foreach ($mod in $modules) {
        if (-not $mod.FileName) { continue }
        $modName = $mod.ModuleName

        $isCandidate = Test-SideloadCandidate -ModuleName $modName `
                                               -FullPath $mod.FileName `
                                               -ProcessDir $procDir

        if ($isCandidate) {
            $isKnownTarget = $KnownSideloadTargets -contains $modName
            $entry = [PSCustomObject]@{
                ProcessName  = $proc.ProcessName
                PID          = $proc.Id
                ProcessPath  = $proc.Path
                DLLName      = $modName
                DLLPath      = $mod.FileName
                KnownTarget  = $isKnownTarget
                Risk         = if ($isKnownTarget) { "HIGH" } else { "MEDIUM" }
            }
            $results.Add($entry)

            $color = if ($isKnownTarget) { "Red" } else { "Yellow" }
            Write-Host "[!] Candidate: $($proc.ProcessName) -> $modName ($($entry.Risk))" -ForegroundColor $color
        }
    }
}

# ---- Output -----------------------------------------------------------------
Write-Host "`n[*] Scan complete. Found $($results.Count) sideload candidate(s)." -ForegroundColor Cyan

if ($results.Count -gt 0) {
    $results | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
    Write-Host "[*] Results saved to $OutputPath" -ForegroundColor Green
    $results | Format-Table ProcessName, PID, DLLName, Risk -AutoSize
}
