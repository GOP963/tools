# APT Emulation Plan Template

> **EDUCATIONAL PURPOSE ONLY** -- This template is designed for use in authorized
> red team exercises within isolated lab environments. All emulation activities
> must be conducted under a signed Rules of Engagement (RoE) document with
> explicit written authorization from the asset owner.

---

## 1. Engagement Metadata

| Field               | Value                                      |
|----------------------|--------------------------------------------|
| Plan ID              | APT-EMU-YYYY-NNN                           |
| Author               |                                            |
| Date Created         |                                            |
| Classification       | CONFIDENTIAL -- Red Team Eyes Only         |
| Approved By          |                                            |
| Target Environment   |                                            |

---

## 2. Threat Actor Profile

| Attribute            | Detail                                     |
|----------------------|--------------------------------------------|
| Actor Name           | APT29 (Cozy Bear)                          |
| Nation-State Sponsor | Russia -- SVR (Foreign Intelligence)       |
| Primary Motivation   | Espionage, intelligence collection         |
| Target Sectors       | Government, think tanks, healthcare, energy |
| Active Since         | 2008                                       |
| Sophistication       | High -- custom tooling, zero-day usage     |
| References           | MITRE ATT&CK Group G0016                   |

---

## 3. TTPs to Emulate (MITRE ATT&CK Mapping)

### Initial Access
| Technique ID  | Name                          | Implementation Notes              |
|---------------|-------------------------------|-----------------------------------|
| T1566.001     | Spearphishing Attachment      | PDF with embedded HTML smuggler   |
| T1566.002     | Spearphishing Link            | Credential harvesting portal      |
| T1195.002     | Supply Chain (Software)       | Trojanized update package         |

### Execution
| Technique ID  | Name                          | Implementation Notes              |
|---------------|-------------------------------|-----------------------------------|
| T1059.001     | PowerShell                    | Encoded loader script             |
| T1204.002     | User Execution: Malicious File| ISO containing LNK payload        |

### Persistence
| Technique ID  | Name                          | Implementation Notes              |
|---------------|-------------------------------|-----------------------------------|
| T1547.001     | Registry Run Keys             | HKCU Run key for beacon           |
| T1053.005     | Scheduled Task                | Daily callback task               |

### Defense Evasion
| Technique ID  | Name                          | Implementation Notes              |
|---------------|-------------------------------|-----------------------------------|
| T1027.006     | HTML Smuggling                | Base64 blob in HTML attachment    |
| T1218.011     | Rundll32                      | DLL side-loading via rundll32     |

### Command and Control
| Technique ID  | Name                          | Implementation Notes              |
|---------------|-------------------------------|-----------------------------------|
| T1071.001     | Web Protocols (HTTPS)         | Domain-fronted C2 channel         |
| T1573.002     | Encrypted Channel: TLS        | Certificate-pinned implant        |

---

## 4. Infrastructure Requirements

| Component              | Specification                              |
|------------------------|--------------------------------------------|
| Phishing Server        | GoPhish instance on VPS, valid TLS cert    |
| Payload Host           | HTTPS file server with domain-fronting     |
| C2 Server              | Cobalt Strike / Sliver teamserver          |
| Redirectors            | 2x HTTPS redirectors (Apache mod_rewrite)  |
| Domain(s)              | Categorized domain, aged > 30 days         |
| Email Infrastructure   | SMTP relay with SPF/DKIM configured        |
| Exfil Channel          | Cloud storage API (OneDrive emulation)     |

---

## 5. Emulation Phases

### Phase 1 -- Reconnaissance (Days 1-3)
- OSINT collection against target organization
- Email address harvesting and validation
- Technology stack fingerprinting (LinkedIn, job postings)
- Identify high-value targets for phishing

### Phase 2 -- Weaponization (Days 4-5)
- Build phishing pretext aligned with actor profile
- Develop HTML smuggling payload (ISO > LNK > DLL)
- Configure C2 infrastructure and test callbacks
- Stage redirectors and verify traffic flow

### Phase 3 -- Initial Access (Days 6-8)
- Deliver spearphishing emails to selected targets
- Monitor for payload execution and callback
- Establish initial foothold on compromised host
- Validate persistence mechanisms

### Phase 4 -- Post-Exploitation (Days 9-12)
- Internal reconnaissance and credential harvesting
- Lateral movement to secondary targets
- Data staging and exfiltration simulation
- Maintain access through remediation attempts

---

## 6. Detection Objectives

The blue team should be evaluated on their ability to detect:

- [ ] Phishing email delivery (email gateway alerting)
- [ ] HTML smuggling payload download (endpoint telemetry)
- [ ] ISO mount and LNK execution (Sysmon events)
- [ ] Suspicious process chain (explorer > cmd > rundll32)
- [ ] C2 beaconing traffic (network anomaly detection)
- [ ] Credential access attempts (Windows Security logs)
- [ ] Lateral movement via pass-the-hash (event 4624 type 9)
- [ ] Data staging in unusual directories
- [ ] Scheduled task persistence (event 4698)

---

## 7. Safety Controls

- Kill switch URL/domain to immediately halt all C2 activity
- Out-of-band communication channel with blue team POC
- Pre-approved IP ranges and target hosts only
- No destructive actions -- data exfil is simulated (marker files)
- Daily check-in with engagement lead at 0900 and 1700

---

## 8. Deliverables

1. Detailed attack narrative with timestamps
2. Evidence package (screenshots, logs, artifacts)
3. MITRE ATT&CK Navigator layer with coverage
4. Detection gap analysis report
5. Remediation recommendations prioritized by risk
