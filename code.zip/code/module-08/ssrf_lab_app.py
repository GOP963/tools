#!/usr/bin/env python3
"""
SSRF Lab Application - Intentionally Vulnerable Flask App
==========================================================

PURPOSE:
    Educational web application with an intentional Server-Side Request Forgery
    (SSRF) vulnerability. Used in isolated lab environments to teach:
    - How SSRF vulnerabilities arise in web applications
    - How attackers exploit SSRF to reach cloud metadata services
    - How to detect, test, and remediate SSRF

    MITRE ATT&CK: T1190 (Exploit Public-Facing Application)
    OWASP Top 10 2021: A10 - Server-Side Request Forgery (SSRF)

USAGE:
    ISOLATED LAB ENVIRONMENTS ONLY - Authorized security testing.
    pip install flask requests
    python3 ssrf_lab_app.py
    Browse to http://localhost:5000

WARNING:
    This application is INTENTIONALLY VULNERABLE. Never deploy it on a
    network accessible to untrusted users. It is designed solely for
    controlled lab exercises.
"""

import re
from urllib.parse import urlparse
from flask import Flask, request, jsonify, render_template_string
import requests as http_client

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Simulated Cloud Metadata Endpoint
# ---------------------------------------------------------------------------
# In a real cloud environment (AWS, GCP, Azure), the metadata service lives
# at 169.254.169.254. This route simulates that service so the lab works
# without actual cloud infrastructure.

SIMULATED_CREDENTIALS = {
    "AccessKeyId": "AKIAIOSFODNN7EXAMPLE",
    "SecretAccessKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    "Token": "FwoGZXIvYXdzEBAaDHqa0AP1/EXAMPLE_TOKEN",
    "Expiration": "2025-12-31T23:59:59Z",
}


@app.route("/metadata/latest/meta-data/iam/security-credentials/lab-role")
def metadata_creds():
    """Simulated EC2 instance metadata - IAM role credentials."""
    # EDUCATIONAL NOTE: On real AWS, this endpoint returns temporary
    # credentials for the IAM role attached to the EC2 instance.
    # SSRF to this endpoint = full cloud account compromise in many cases.
    return jsonify(SIMULATED_CREDENTIALS)


@app.route("/metadata/latest/meta-data/instance-id")
def metadata_instance_id():
    """Simulated EC2 instance metadata - instance identity."""
    return "i-0abc1234def567890"


# ---------------------------------------------------------------------------
# Vulnerable Endpoint: URL Fetcher (NO input validation)
# ---------------------------------------------------------------------------
HOME_PAGE = """
<!DOCTYPE html>
<html>
<head><title>URL Preview Service (Lab)</title></head>
<body>
<h1>URL Preview Service</h1>
<p><strong>Lab Exercise:</strong> This service fetches and previews URLs.
   It contains an SSRF vulnerability. Try fetching the cloud metadata endpoint.</p>
<form method="POST" action="/fetch">
    <label>Enter a URL to preview:</label><br>
    <input type="text" name="url" size="60"
           placeholder="http://169.254.169.254/metadata/latest/meta-data/..."><br><br>
    <button type="submit">Fetch URL</button>
</form>
<hr>
<h3>Hints for lab exercise:</h3>
<ul>
    <li>Try: <code>http://127.0.0.1:5000/metadata/latest/meta-data/iam/security-credentials/lab-role</code></li>
    <li>The "patched" version is at <code>/fetch-safe</code></li>
</ul>
</body>
</html>
"""


@app.route("/")
def home():
    return render_template_string(HOME_PAGE)


@app.route("/fetch", methods=["POST"])
def fetch_vulnerable():
    """
    VULNERABLE ENDPOINT - No SSRF protections.

    This endpoint takes a user-supplied URL and fetches it from the SERVER side.
    An attacker can supply internal/metadata URLs to access resources that are
    only reachable from the server's network position.
    """
    url = request.form.get("url", "")
    if not url:
        return "Error: No URL provided.", 400

    # VULNERABILITY: The URL is fetched without ANY validation.
    # No allowlist, no blocklist, no schema check, no IP restriction.
    try:
        resp = http_client.get(url, timeout=5)
        return (
            f"<h2>Response from: {url}</h2>"
            f"<p>Status: {resp.status_code}</p>"
            f"<pre>{resp.text}</pre>"
            f"<p><a href='/'>Back</a></p>"
        )
    except Exception as exc:
        return f"<h2>Error fetching URL</h2><pre>{exc}</pre>", 500


# ---------------------------------------------------------------------------
# Patched Endpoint: URL Fetcher WITH SSRF mitigations
# ---------------------------------------------------------------------------
# Allowlist of permitted domains (defense-in-depth).
ALLOWED_DOMAINS = {"example.com", "httpbin.org", "api.github.com"}

# Blocked IP ranges (internal networks, link-local, loopback).
BLOCKED_PATTERNS = [
    re.compile(r"^127\."),                   # Loopback
    re.compile(r"^10\."),                     # RFC 1918
    re.compile(r"^172\.(1[6-9]|2\d|3[01])\."),  # RFC 1918
    re.compile(r"^192\.168\."),               # RFC 1918
    re.compile(r"^169\.254\."),               # Link-local / metadata
    re.compile(r"^0\."),                      # Current network
]


def is_safe_url(url: str) -> tuple[bool, str]:
    """
    Validate a URL against SSRF protections.

    Returns (is_safe, reason) tuple.
    """
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "Invalid URL format."

    # 1. Enforce HTTPS only (prevents scheme-based bypasses like file://, gopher://).
    if parsed.scheme not in ("http", "https"):
        return False, f"Blocked scheme: {parsed.scheme}. Only http/https allowed."

    # 2. Domain allowlist check.
    hostname = parsed.hostname
    if not hostname:
        return False, "No hostname found in URL."
    if hostname not in ALLOWED_DOMAINS:
        return False, f"Domain '{hostname}' is not in the allowlist."

    # 3. Block internal/reserved IP ranges.
    # NOTE: A production implementation should also resolve the hostname and
    # check the resolved IP, to prevent DNS rebinding attacks.
    import socket
    try:
        resolved_ip = socket.gethostbyname(hostname)
    except socket.gaierror:
        return False, f"Cannot resolve hostname: {hostname}"

    for pattern in BLOCKED_PATTERNS:
        if pattern.match(resolved_ip):
            return False, f"Blocked: {hostname} resolves to internal IP {resolved_ip}."

    return True, "OK"


@app.route("/fetch-safe", methods=["POST"])
def fetch_patched():
    """
    PATCHED ENDPOINT - With SSRF mitigations.

    Mitigations applied:
    - Schema restriction (http/https only)
    - Domain allowlist
    - DNS resolution check against internal IP ranges
    """
    url = request.form.get("url", "")
    if not url:
        return "Error: No URL provided.", 400

    is_safe, reason = is_safe_url(url)
    if not is_safe:
        return (
            f"<h2>Request Blocked (SSRF Protection)</h2>"
            f"<p>Reason: {reason}</p>"
            f"<p><a href='/'>Back</a></p>"
        ), 403

    try:
        resp = http_client.get(url, timeout=5)
        return (
            f"<h2>Response from: {url}</h2>"
            f"<p>Status: {resp.status_code}</p>"
            f"<pre>{resp.text}</pre>"
            f"<p><a href='/'>Back</a></p>"
        )
    except Exception as exc:
        return f"<h2>Error fetching URL</h2><pre>{exc}</pre>", 500


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("[*] SSRF Lab Application - INTENTIONALLY VULNERABLE")
    print("[*] For isolated lab environments ONLY.")
    print("[*] Vulnerable endpoint: POST /fetch")
    print("[*] Patched endpoint:    POST /fetch-safe")
    print("[*] Metadata simulation: /metadata/latest/meta-data/...")
    print()
    # Debug mode for lab convenience; NEVER use debug=True in production.
    app.run(host="127.0.0.1", port=5000, debug=True)
