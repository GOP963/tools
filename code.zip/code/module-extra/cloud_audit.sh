#!/usr/bin/env bash
# =============================================================================
# cloud_audit.sh - Cloud Security Audit Wrapper Script
# =============================================================================
# EDUCATIONAL PURPOSE ONLY - For use in authorized security assessments
# within isolated lab environments.
#
# Runs ScoutSuite or Prowler for cloud security auditing and extracts
# findings relevant to initial access attack surface.
#
# Usage: ./cloud_audit.sh --provider <aws|azure|gcp> [--tool <scoutsuite|prowler>]
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

PROVIDER=""
TOOL="scoutsuite"
OUTPUT_DIR="./cloud_audit_results_$(date +%Y%m%d_%H%M%S)"

log_info()  { echo -e "${GREEN}[+]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
log_error() { echo -e "${RED}[-]${NC} $1"; }
log_section() { echo -e "\n${CYAN}[*] $1${NC}"; }

usage() {
    echo "Usage: $0 --provider <aws|azure|gcp> [--tool <scoutsuite|prowler>]"
    echo ""
    echo "Options:"
    echo "  --provider    Cloud provider to audit (aws, azure, gcp)"
    echo "  --tool        Audit tool to use (scoutsuite or prowler, default: scoutsuite)"
    echo "  --help        Show this help message"
    exit 1
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --provider) PROVIDER="$2"; shift 2 ;;
        --tool)     TOOL="$2"; shift 2 ;;
        --help)     usage ;;
        *)          log_error "Unknown option: $1"; usage ;;
    esac
done

if [[ -z "$PROVIDER" ]]; then
    log_error "Provider is required."
    usage
fi

mkdir -p "$OUTPUT_DIR"
log_info "Audit output directory: $OUTPUT_DIR"

run_scoutsuite() {
    log_section "Running ScoutSuite for $PROVIDER"
    if ! command -v scout &> /dev/null; then
        log_error "ScoutSuite is not installed. Install with: pip install scoutsuite"
        exit 1
    fi
    scout "$PROVIDER" --no-browser --report-dir "$OUTPUT_DIR/scoutsuite" 2>&1 | tee "$OUTPUT_DIR/scoutsuite_raw.log"
}

run_prowler() {
    log_section "Running Prowler for $PROVIDER"
    if ! command -v prowler &> /dev/null; then
        log_error "Prowler is not installed. See: https://github.com/prowler-cloud/prowler"
        exit 1
    fi
    prowler "$PROVIDER" -M csv json -o "$OUTPUT_DIR/prowler" 2>&1 | tee "$OUTPUT_DIR/prowler_raw.log"
}

extract_initial_access_findings() {
    log_section "Extracting initial access relevant findings"

    local report_file="$OUTPUT_DIR/initial_access_findings.txt"

    echo "=============================================" > "$report_file"
    echo " Initial Access Relevant Cloud Findings"       >> "$report_file"
    echo " Provider: $PROVIDER"                          >> "$report_file"
    echo " Date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"        >> "$report_file"
    echo "=============================================" >> "$report_file"
    echo ""                                              >> "$report_file"

    local keywords="public|exposed|anonymous|unauthenticated|open|password|mfa|credential|login|sign-in|federation|external|guest|conditional.access"

    if [[ -f "$OUTPUT_DIR/scoutsuite_raw.log" ]]; then
        echo "--- ScoutSuite Findings ---" >> "$report_file"
        grep -iE "$keywords" "$OUTPUT_DIR/scoutsuite_raw.log" >> "$report_file" 2>/dev/null || echo "No matches found." >> "$report_file"
    fi

    if [[ -d "$OUTPUT_DIR/prowler" ]]; then
        echo "" >> "$report_file"
        echo "--- Prowler Findings ---" >> "$report_file"
        find "$OUTPUT_DIR/prowler" -name "*.csv" -exec grep -ihE "$keywords" {} + >> "$report_file" 2>/dev/null || echo "No matches found." >> "$report_file"
    fi

    local count
    count=$(grep -cE "$keywords" "$report_file" 2>/dev/null || echo "0")
    log_info "Found $count initial-access-relevant findings"
    log_info "Full report: $report_file"
}

case "$TOOL" in
    scoutsuite) run_scoutsuite ;;
    prowler)    run_prowler ;;
    *)          log_error "Unsupported tool: $TOOL. Use scoutsuite or prowler."; exit 1 ;;
esac

extract_initial_access_findings

log_section "Audit Summary"
log_info "Provider:    $PROVIDER"
log_info "Tool:        $TOOL"
log_info "Results:     $OUTPUT_DIR"
log_info "Review $OUTPUT_DIR/initial_access_findings.txt for initial access surface analysis"
