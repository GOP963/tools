#!/usr/bin/env bash
# =============================================================================
# gophish_setup.sh - GoPhish Installation and Hardening Script
#
# Downloads GoPhish, hardens the default configuration, configures TLS,
# removes default fingerprints, and sets up a systemd service.
#
# DISCLAIMER: For AUTHORIZED SECURITY TESTING in isolated lab environments
# only. Phishing simulations must be conducted with explicit organizational
# approval and within a defined scope. Unauthorized phishing is illegal.
#
# Usage:
#   chmod +x gophish_setup.sh
#   sudo ./gophish_setup.sh
#
# Tested on: Ubuntu 22.04 / Debian 12
# =============================================================================

set -euo pipefail

# ---- Configuration ----------------------------------------------------------
GOPHISH_VERSION="0.12.1"
GOPHISH_DIR="/opt/gophish"
GOPHISH_USER="gophish"
GOPHISH_GROUP="gophish"
ADMIN_LISTEN="127.0.0.1:3333"
PHISH_LISTEN="0.0.0.0:443"
TLS_CERT="/etc/gophish/tls/server.crt"
TLS_KEY="/etc/gophish/tls/server.key"
DOWNLOAD_URL="https://github.com/gophish/gophish/releases/download/v${GOPHISH_VERSION}/gophish-v${GOPHISH_VERSION}-linux-64bit.zip"

# ---- Color helpers ----------------------------------------------------------
info()  { echo -e "\033[0;32m[+]\033[0m $*"; }
warn()  { echo -e "\033[1;33m[!]\033[0m $*"; }
error() { echo -e "\033[0;31m[-]\033[0m $*" >&2; }

# ---- Root check -------------------------------------------------------------
if [[ "${EUID}" -ne 0 ]]; then
    error "This script must be run as root (sudo)."
    exit 1
fi

# ---- Step 1: Install dependencies -------------------------------------------
info "Installing dependencies..."
apt-get update -qq
apt-get install -y -qq unzip curl openssl > /dev/null

# ---- Step 2: Create service account -----------------------------------------
info "Creating gophish service account..."
if ! id "${GOPHISH_USER}" &>/dev/null; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "${GOPHISH_USER}"
fi

# ---- Step 3: Download and extract GoPhish -----------------------------------
info "Downloading GoPhish v${GOPHISH_VERSION}..."
TMPDIR=$(mktemp -d)
curl -sL "${DOWNLOAD_URL}" -o "${TMPDIR}/gophish.zip"

info "Extracting to ${GOPHISH_DIR}..."
mkdir -p "${GOPHISH_DIR}"
unzip -qo "${TMPDIR}/gophish.zip" -d "${GOPHISH_DIR}"
rm -rf "${TMPDIR}"
chmod 750 "${GOPHISH_DIR}"
chmod +x "${GOPHISH_DIR}/gophish"

# ---- Step 4: Generate self-signed TLS certificate ---------------------------
info "Generating self-signed TLS certificate..."
mkdir -p "$(dirname "${TLS_CERT}")"
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout "${TLS_KEY}" \
    -out "${TLS_CERT}" \
    -subj "/CN=phish-lab.local/O=Security Lab/C=US" \
    2>/dev/null
chmod 640 "${TLS_KEY}" "${TLS_CERT}"
chown "${GOPHISH_USER}:${GOPHISH_GROUP}" "${TLS_KEY}" "${TLS_CERT}"

# ---- Step 5: Harden configuration -------------------------------------------
info "Writing hardened config.json..."
cat > "${GOPHISH_DIR}/config.json" <<CONF
{
    "admin_server": {
        "listen_url": "${ADMIN_LISTEN}",
        "use_tls": true,
        "cert_path": "${TLS_CERT}",
        "key_path": "${TLS_KEY}"
    },
    "phish_server": {
        "listen_url": "${PHISH_LISTEN}",
        "use_tls": true,
        "cert_path": "${TLS_CERT}",
        "key_path": "${TLS_KEY}"
    },
    "db_name": "sqlite3",
    "db_path": "${GOPHISH_DIR}/gophish.db",
    "migrations_prefix": "db/db_",
    "contact_address": "admin@lab.local",
    "logging": {
        "filename": "/var/log/gophish.log",
        "level": "info"
    }
}
CONF

# ---- Step 6: Remove default fingerprints ------------------------------------
info "Removing default GoPhish fingerprints..."

# Remove the X-GoPhish-Signature header from the source (binary patching)
# For a source build you would edit controllers/phish.go.
# For the binary release, we patch the known header string.
if command -v sed &>/dev/null; then
    # Replace "X-Gophish-Contact" and "X-Gophish-Signature" strings in binary
    sed -i 's/X-Gophish-Contact/X-Contact-Hidden__/g' "${GOPHISH_DIR}/gophish" 2>/dev/null || true
    sed -i 's/X-Gophish-Signature/X-Signature-Hide__/g' "${GOPHISH_DIR}/gophish" 2>/dev/null || true
fi

# Replace default 404 page to avoid fingerprinting
cat > "${GOPHISH_DIR}/static/endpoint/404.html" <<'HTML'
<!DOCTYPE html>
<html><head><title>Not Found</title></head>
<body><h1>404 - Page Not Found</h1></body></html>
HTML

info "Fingerprint removal complete."

# ---- Step 7: Set ownership --------------------------------------------------
chown -R "${GOPHISH_USER}:${GOPHISH_GROUP}" "${GOPHISH_DIR}"
touch /var/log/gophish.log
chown "${GOPHISH_USER}:${GOPHISH_GROUP}" /var/log/gophish.log

# ---- Step 8: Create systemd service -----------------------------------------
info "Creating systemd service..."
cat > /etc/systemd/system/gophish.service <<SERVICE
[Unit]
Description=GoPhish Phishing Simulation Platform
Documentation=https://docs.getgophish.com/
After=network.target

[Service]
Type=simple
User=${GOPHISH_USER}
Group=${GOPHISH_GROUP}
WorkingDirectory=${GOPHISH_DIR}
ExecStart=${GOPHISH_DIR}/gophish
Restart=on-failure
RestartSec=5
AmbientCapabilities=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable gophish.service
info "Systemd service created and enabled."

# ---- Step 9: Print post-install instructions --------------------------------
echo ""
info "============================================================"
info "  GoPhish installation complete."
info ""
info "  Admin panel : https://${ADMIN_LISTEN}"
info "  Phish server: https://${PHISH_LISTEN}"
info ""
info "  IMPORTANT: On first login, GoPhish generates a random"
info "  admin password. Retrieve it from the log:"
info "    grep 'Please login with' /var/log/gophish.log"
info ""
info "  Change the default password immediately after first login."
info ""
info "  Start the service:"
info "    sudo systemctl start gophish"
info "============================================================"
