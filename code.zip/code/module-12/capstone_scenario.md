# Capstone Exercise: Full-Scope Initial Access Engagement

> **EDUCATIONAL PURPOSE ONLY** -- This scenario is designed for use in isolated
> lab environments as part of an authorized offensive security training course.
> All activities must remain within the provided lab infrastructure.

---

## 1. Scenario Briefing

You have been engaged by **AcmeCorp Industries** to conduct a red team
assessment focused on initial access vectors. AcmeCorp is a mid-size
manufacturing company that has recently migrated core services to a hybrid
cloud environment. Following a series of industry-wide breaches, AcmeCorp's
CISO has authorized a realistic adversary simulation to evaluate the
organization's defenses against modern phishing and initial access techniques.

---

## 2. Target Company Profile

| Attribute                | Detail                                    |
|--------------------------|-------------------------------------------|
| Company Name             | AcmeCorp Industries                       |
| Industry                 | Manufacturing / Industrial IoT            |
| Employees                | ~2,500                                    |
| Headquarters             | Chicago, IL                               |
| IT Environment           | Hybrid (on-prem AD + Azure AD)            |
| Email Platform            | Microsoft 365 (Exchange Online)           |
| Endpoint Protection      | Microsoft Defender for Endpoint           |
| Email Gateway            | Microsoft Defender for Office 365         |
| Web Proxy                | Zscaler Internet Access                   |
| SIEM                     | Microsoft Sentinel                        |
| MFA Solution             | Azure AD MFA (push notifications)         |
| Domain                   | acmecorp-lab.local (internal)             |
| External Domain          | acmecorp-lab.com (lab simulation)         |

### Key Personnel (Lab Personas)

| Name               | Role                      | Email                          |
|--------------------|---------------------------|--------------------------------|
| Sarah Mitchell     | CFO                       | s.mitchell@acmecorp-lab.com    |
| David Chen         | IT Director               | d.chen@acmecorp-lab.com        |
| Lisa Park          | HR Manager                | l.park@acmecorp-lab.com        |
| James Wilson       | Procurement Lead          | j.wilson@acmecorp-lab.com      |
| Maria Garcia       | Executive Assistant       | m.garcia@acmecorp-lab.com      |
| Tom Baker          | Help Desk Analyst         | t.baker@acmecorp-lab.com       |

---

## 3. Rules of Engagement

### 3.1 Authorized Activities

- OSINT reconnaissance against lab-provided target information only
- Phishing campaigns targeting listed lab personas
- Credential harvesting via controlled phishing infrastructure
- Payload delivery using HTML smuggling, ISO containers, or LNK files
- AiTM proxy deployment for session cookie capture (lab environment)
- Password spraying against lab Azure AD tenant

### 3.2 Prohibited Activities

- Any activity against real-world infrastructure or personnel
- Denial-of-service attacks against any lab component
- Modification or deletion of blue team monitoring infrastructure
- Exploitation of vulnerabilities not related to initial access
- Social engineering via telephone or physical means
- Sharing lab credentials or infrastructure outside the course

### 3.3 Deconfliction

- Lab coordinator contact: instructor@lab-environment.local
- Emergency stop: Disable all C2 and notify coordinator immediately
- Daily check-in: Submit brief status update by 1700 local time

---

## 4. Objectives

Complete the following objectives. Each builds upon the previous and
reflects a realistic adversary workflow.

### Objective 1: Reconnaissance and Target Selection (10%)
- Enumerate target organization using provided OSINT sources
- Identify the three most promising phishing targets with justification
- Document the email naming convention and technology stack
- **Deliverable:** Reconnaissance summary document

### Objective 2: Infrastructure Preparation (15%)
- Deploy phishing infrastructure (GoPhish or equivalent)
- Configure a credible sending domain with SPF/DKIM
- Set up payload hosting with HTTPS and valid certificate
- Prepare at least one C2 channel with a redirector
- **Deliverable:** Infrastructure diagram and domain configuration

### Objective 3: Payload Development (20%)
- Create an HTML smuggling page that delivers an ISO container
- The ISO must contain a LNK file that executes a payload
- Payload must establish a C2 callback to your infrastructure
- Test payload against lab endpoint protection
- **Deliverable:** Payload source files and test results

### Objective 4: Phishing Campaign Execution (20%)
- Craft a convincing phishing pretext appropriate to the target
- Send phishing emails to selected targets
- Track email opens, link clicks, and payload executions
- Achieve at least one successful C2 callback
- **Deliverable:** Campaign statistics and execution evidence

### Objective 5: Credential Harvesting via AiTM (15%)
- Deploy an AiTM reverse-proxy targeting the lab M365 tenant
- Capture at least one session token via the proxy
- Demonstrate session replay to access the target mailbox
- **Deliverable:** AiTM deployment documentation and session evidence

### Objective 6: Detection and Reporting (20%)
- Write Sigma rules or KQL queries to detect your own attack chain
- Identify which phases were detected by the lab's blue team tooling
- Produce an executive report using the provided template
- Include a MITRE ATT&CK Navigator layer for your engagement
- **Deliverable:** Detection rules, gap analysis, and final report

---

## 5. Grading Criteria

| Criterion                        | Weight | Evaluation Basis               |
|----------------------------------|--------|--------------------------------|
| Technical execution quality      | 30%    | Successful objective completion|
| Operational security             | 15%    | OPSEC checklist adherence      |
| Creativity and realism           | 15%    | Pretext quality, evasion depth |
| Detection engineering            | 20%    | Rule quality and coverage      |
| Report quality                   | 20%    | Clarity, completeness, utility |

---

## 6. Lab Access

| Resource                 | Access Method                             |
|--------------------------|-------------------------------------------|
| Attacker VM              | SSH/RDP via lab VPN                       |
| Target Environment       | Accessible from attacker VM network       |
| Azure AD Tenant          | Lab tenant credentials provided in class  |
| GoPhish Instance         | Pre-deployed on attacker VM               |
| C2 Framework             | Pre-installed on attacker VM              |
| SIEM (Sentinel)          | Read-only access for detection review     |

---

## 7. Submission Requirements

- All deliverables submitted via the lab portal by the deadline
- Final report in PDF format using the provided template
- Source code and configuration files in a compressed archive
- Attack narrative with timestamps aligned to lab SIEM logs
- Self-assessment against the OPSEC checklist

---

*Good luck. Think like an adversary, report like a professional.*
