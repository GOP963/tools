<#
.SYNOPSIS
    motw_checker.ps1 - Check Mark of the Web (MoTW) Status on Files

.DESCRIPTION
    This script inspects the Zone.Identifier Alternate Data Stream (ADS) on
    files to determine whether Mark of the Web is present.  MoTW is a Windows
    security mechanism that tags files downloaded from the internet with their
    source zone, triggering additional security prompts and SmartScreen checks.

    Understanding MoTW behavior is critical for:
      - Detecting initial access payloads that bypass MoTW
      - Validating that security controls (SmartScreen, Protected View) activate
      - Analyzing container-based MoTW bypass techniques (ISO, VHD, etc.)

.DISCLAIMER
    For AUTHORIZED SECURITY TESTING in isolated lab environments only.

.PARAMETER Path
    File or directory path to check.  Defaults to the current directory.

.PARAMETER Recurse
    If specified, recursively scan subdirectories.

.EXAMPLE
    .\motw_checker.ps1 -Path C:\Users\analyst\Downloads
    .\motw_checker.ps1 -Path C:\Payloads -Recurse
#>

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$Path = (Get-Location).Path,

    [switch]$Recurse
)

# ---- Constants ---------------------------------------------------------------
$ZoneIdStream = "Zone.Identifier"
$ZoneDescriptions = @{
    "0" = "Local Machine"
    "1" = "Local Intranet"
    "2" = "Trusted Sites"
    "3" = "Internet"
    "4" = "Restricted Sites"
}

# ---- Functions ---------------------------------------------------------------
function Get-MotWInfo {
    <#
    .SYNOPSIS
        Reads the Zone.Identifier ADS from a single file and returns
        a structured object with MoTW details.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.IO.FileInfo]$File
    )

    $result = [PSCustomObject]@{
        FileName    = $File.Name
        FullPath    = $File.FullName
        HasMoTW     = $false
        ZoneId      = $null
        ZoneDesc    = "N/A"
        ReferrerUrl = $null
        HostUrl     = $null
        RawContent  = $null
    }

    try {
        # Check whether the Zone.Identifier ADS exists
        $streamPath = "$($File.FullName):$ZoneIdStream"
        $content = Get-Content -Path $streamPath -ErrorAction Stop

        $result.HasMoTW    = $true
        $result.RawContent = ($content -join "`n")

        # Parse key-value pairs from the stream
        foreach ($line in $content) {
            if ($line -match "^ZoneId\s*=\s*(\d+)") {
                $result.ZoneId   = $Matches[1]
                $result.ZoneDesc = if ($ZoneDescriptions.ContainsKey($Matches[1])) {
                    $ZoneDescriptions[$Matches[1]]
                } else {
                    "Unknown ($($Matches[1]))"
                }
            }
            if ($line -match "^ReferrerUrl\s*=\s*(.+)") {
                $result.ReferrerUrl = $Matches[1].Trim()
            }
            if ($line -match "^HostUrl\s*=\s*(.+)") {
                $result.HostUrl = $Matches[1].Trim()
            }
        }
    }
    catch [System.Management.Automation.ItemNotFoundException] {
        # No Zone.Identifier stream -- MoTW is absent
        $result.HasMoTW = $false
    }
    catch {
        Write-Warning "Error reading MoTW for $($File.FullName): $_"
    }

    return $result
}

# ---- Main --------------------------------------------------------------------
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Mark of the Web (MoTW) Checker" -ForegroundColor Cyan
Write-Host "  Target: $Path" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Resolve target -- single file or directory
if (Test-Path -Path $Path -PathType Leaf) {
    $files = @(Get-Item -Path $Path)
}
elseif (Test-Path -Path $Path -PathType Container) {
    $gciParams = @{ Path = $Path; File = $true }
    if ($Recurse) { $gciParams.Recurse = $true }
    $files = @(Get-ChildItem @gciParams)
}
else {
    Write-Error "Path not found: $Path"
    exit 1
}

if ($files.Count -eq 0) {
    Write-Warning "No files found at the specified path."
    exit 0
}

# Process each file
$results = foreach ($f in $files) {
    Get-MotWInfo -File $f
}

# ---- Display results ---------------------------------------------------------
$withMotW    = @($results | Where-Object { $_.HasMoTW -eq $true })
$withoutMotW = @($results | Where-Object { $_.HasMoTW -eq $false })

Write-Host "Files WITH MoTW ($($withMotW.Count)):" -ForegroundColor Green
foreach ($r in $withMotW) {
    Write-Host "  [Zone $($r.ZoneId) - $($r.ZoneDesc)] $($r.FullPath)" -ForegroundColor Green
    if ($r.ReferrerUrl) { Write-Host "    Referrer : $($r.ReferrerUrl)" -ForegroundColor Gray }
    if ($r.HostUrl)     { Write-Host "    Host URL : $($r.HostUrl)" -ForegroundColor Gray }
}

Write-Host ""
Write-Host "Files WITHOUT MoTW ($($withoutMotW.Count)):" -ForegroundColor Yellow
foreach ($r in $withoutMotW) {
    Write-Host "  $($r.FullPath)" -ForegroundColor Yellow
}

# ---- Summary -----------------------------------------------------------------
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Total files scanned : $($results.Count)"
Write-Host "  With MoTW           : $($withMotW.Count)"
Write-Host "  Without MoTW        : $($withoutMotW.Count)"
Write-Host "============================================" -ForegroundColor Cyan

# Optionally export to CSV
$csvPath = Join-Path -Path (Split-Path $Path -Parent) -ChildPath "motw_report_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
$results | Select-Object FileName, FullPath, HasMoTW, ZoneId, ZoneDesc, ReferrerUrl, HostUrl |
    Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
Write-Host ""
Write-Host "CSV report saved to: $csvPath" -ForegroundColor Cyan
