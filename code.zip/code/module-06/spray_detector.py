#!/usr/bin/env python3
"""
Password Spray Detection Script - Educational Tool
===================================================

PURPOSE:
    Analyze authentication logs to detect password spray attack patterns.
    Password spraying tries a small number of common passwords against MANY
    accounts to stay below per-account lockout thresholds.

DETECTION LOGIC:
    1. Sliding time-window analysis for clusters of failed authentications.
    2. Track unique accounts targeted from each source IP.
    3. Alert when a single source hits more accounts than a configurable threshold
       within the detection window.

USAGE:
    ISOLATED LAB ENVIRONMENTS ONLY - Authorized security testing.
    python3 spray_detector.py --logfile auth.log
    python3 spray_detector.py --demo   (runs against embedded sample data)

SAMPLE LOG FORMAT (one JSON object per line):
    {"timestamp":"2025-03-15T09:00:01Z","source_ip":"192.168.1.100",
     "username":"jdoe","result":"failure","service":"OWA"}
"""

import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
WINDOW_SECONDS = 600          # 10-minute sliding window
ACCOUNT_THRESHOLD = 5         # Unique failed accounts from one IP triggers alert
FAILURE_THRESHOLD = 10        # Total failures from one IP triggers alert
TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

# ---------------------------------------------------------------------------
# Sample log data for --demo mode
# ---------------------------------------------------------------------------
SAMPLE_LOGS = [
    {"timestamp": "2025-03-15T09:00:01Z", "source_ip": "192.168.1.100", "username": "alice",   "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:03Z", "source_ip": "192.168.1.100", "username": "bob",     "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:05Z", "source_ip": "192.168.1.100", "username": "charlie", "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:08Z", "source_ip": "192.168.1.100", "username": "diana",   "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:10Z", "source_ip": "192.168.1.100", "username": "eve",     "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:12Z", "source_ip": "192.168.1.100", "username": "frank",   "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:15Z", "source_ip": "192.168.1.100", "username": "grace",   "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:01:00Z", "source_ip": "10.0.0.5",     "username": "admin",   "result": "failure", "service": "SSH"},
    {"timestamp": "2025-03-15T09:05:00Z", "source_ip": "10.0.0.5",     "username": "admin",   "result": "success", "service": "SSH"},
    {"timestamp": "2025-03-15T09:00:20Z", "source_ip": "192.168.1.100", "username": "henry",   "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:22Z", "source_ip": "192.168.1.100", "username": "iris",    "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:25Z", "source_ip": "192.168.1.100", "username": "jack",    "result": "failure", "service": "OWA"},
    {"timestamp": "2025-03-15T09:00:30Z", "source_ip": "192.168.1.100", "username": "alice",   "result": "success", "service": "OWA"},
]


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------
@dataclass
class AuthEvent:
    """Represents a single authentication event."""
    timestamp: datetime
    source_ip: str
    username: str
    result: str          # "success" or "failure"
    service: str


@dataclass
class SprayAlert:
    """Represents a detected password spray alert."""
    source_ip: str
    window_start: datetime
    window_end: datetime
    unique_accounts: int
    total_failures: int
    targeted_accounts: list
    service: str

    def __str__(self) -> str:
        return (
            f"[ALERT] Password Spray Detected\n"
            f"  Source IP       : {self.source_ip}\n"
            f"  Time Window    : {self.window_start.isoformat()} -> {self.window_end.isoformat()}\n"
            f"  Unique Accounts: {self.unique_accounts}\n"
            f"  Total Failures : {self.total_failures}\n"
            f"  Service        : {self.service}\n"
            f"  Accounts Hit   : {', '.join(self.targeted_accounts)}\n"
        )


# ---------------------------------------------------------------------------
# Core Detection Engine
# ---------------------------------------------------------------------------
class SprayDetector:
    """Sliding-window password spray detector."""

    def __init__(
        self,
        window_seconds: int = WINDOW_SECONDS,
        account_threshold: int = ACCOUNT_THRESHOLD,
        failure_threshold: int = FAILURE_THRESHOLD,
    ):
        self.window = timedelta(seconds=window_seconds)
        self.account_threshold = account_threshold
        self.failure_threshold = failure_threshold
        # Per-source tracking: source_ip -> list of AuthEvents
        self.events_by_source: dict[str, list[AuthEvent]] = defaultdict(list)
        self.alerts: list[SprayAlert] = []

    def ingest(self, event: AuthEvent) -> Optional[SprayAlert]:
        """Process a single auth event; return an alert if thresholds are met."""
        if event.result != "failure":
            return None

        bucket = self.events_by_source[event.source_ip]
        bucket.append(event)

        # Prune events outside the sliding window.
        cutoff = event.timestamp - self.window
        self.events_by_source[event.source_ip] = [
            e for e in bucket if e.timestamp >= cutoff
        ]
        bucket = self.events_by_source[event.source_ip]

        # Evaluate thresholds.
        unique_accounts = set(e.username for e in bucket)
        if (
            len(unique_accounts) >= self.account_threshold
            or len(bucket) >= self.failure_threshold
        ):
            alert = SprayAlert(
                source_ip=event.source_ip,
                window_start=bucket[0].timestamp,
                window_end=bucket[-1].timestamp,
                unique_accounts=len(unique_accounts),
                total_failures=len(bucket),
                targeted_accounts=sorted(unique_accounts),
                service=event.service,
            )
            # Avoid duplicate alerts for the same window by resetting.
            self.events_by_source[event.source_ip] = []
            self.alerts.append(alert)
            return alert
        return None


# ---------------------------------------------------------------------------
# Log Parsing
# ---------------------------------------------------------------------------
def parse_event(raw: dict) -> AuthEvent:
    """Parse a JSON log entry into an AuthEvent."""
    return AuthEvent(
        timestamp=datetime.strptime(raw["timestamp"], TIME_FORMAT).replace(
            tzinfo=timezone.utc
        ),
        source_ip=raw["source_ip"],
        username=raw["username"],
        result=raw["result"],
        service=raw.get("service", "unknown"),
    )


def load_events_from_file(path: str) -> list[AuthEvent]:
    """Load newline-delimited JSON log entries from a file."""
    events = []
    with open(path, "r") as fh:
        for line_num, line in enumerate(fh, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                events.append(parse_event(json.loads(line)))
            except (json.JSONDecodeError, KeyError) as exc:
                print(f"[WARN] Skipping malformed line {line_num}: {exc}",
                      file=sys.stderr)
    return events


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Password Spray Detector")
    parser.add_argument("--logfile", help="Path to JSON auth log file")
    parser.add_argument("--demo", action="store_true",
                        help="Run against embedded sample data")
    parser.add_argument("--window", type=int, default=WINDOW_SECONDS,
                        help=f"Detection window in seconds (default {WINDOW_SECONDS})")
    parser.add_argument("--threshold", type=int, default=ACCOUNT_THRESHOLD,
                        help=f"Unique account threshold (default {ACCOUNT_THRESHOLD})")
    args = parser.parse_args()

    if not args.logfile and not args.demo:
        parser.print_help()
        sys.exit(1)

    # Load events.
    if args.demo:
        print("[*] Running in demo mode with sample log data.\n")
        events = [parse_event(entry) for entry in SAMPLE_LOGS]
    else:
        print(f"[*] Loading events from {args.logfile}")
        events = load_events_from_file(args.logfile)

    # Sort chronologically and run detection.
    events.sort(key=lambda e: e.timestamp)
    detector = SprayDetector(
        window_seconds=args.window,
        account_threshold=args.threshold,
    )

    print(f"[*] Analyzing {len(events)} events "
          f"(window={args.window}s, threshold={args.threshold} accounts)\n")

    for event in events:
        alert = detector.ingest(event)
        if alert:
            print(alert)

    # Summary
    total_alerts = len(detector.alerts)
    if total_alerts == 0:
        print("[*] No password spray patterns detected.")
    else:
        print(f"[*] Total alerts generated: {total_alerts}")


if __name__ == "__main__":
    main()
