#!/usr/bin/env bash
# =============================================================================
# domain_recon.sh - Bash Wrapper for Domain Reconnaissance
#
# Runs amass, subfinder, and httpx in sequence, deduplicates results, and
# generates a summary report.
#
# DISCLAIMER: For AUTHORIZED SECURITY TESTING in isolated lab environments
# only. Obtain written permission before scanning any target. Unauthorized
# reconnaissance is illegal.
#
# Usage:
#   chmod +x domain_recon.sh
#   ./domain_recon.sh -d example.com [-o output_dir]
#
# Prerequisites:
#   - amass   (https://github.com/owasp-amass/amass)
#   - subfinder (https://github.com/projectdiscovery/subfinder)
#   - httpx   (https://github.com/projectdiscovery/httpx)
# =============================================================================

set -euo pipefail

# ---- Defaults ---------------------------------------------------------------
DOMAIN=""
OUTPUT_DIR="./recon_output"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# ---- Color helpers ----------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

info()  { echo -e "${GREEN}[+]${NC} $*"; }
warn()  { echo -e "${YELLOW}[!]${NC} $*"; }
error() { echo -e "${RED}[-]${NC} $*" >&2; }

# ---- Usage ------------------------------------------------------------------
usage() {
    echo "Usage: $0 -d <domain> [-o <output_dir>]"
    echo "  -d  Target domain (required)"
    echo "  -o  Output directory (default: ./recon_output)"
    exit 1
}

# ---- Argument parsing -------------------------------------------------------
while getopts "d:o:h" opt; do
    case "${opt}" in
        d) DOMAIN="${OPTARG}" ;;
        o) OUTPUT_DIR="${OPTARG}" ;;
        h|*) usage ;;
    esac
done

if [[ -z "${DOMAIN}" ]]; then
    error "Target domain is required."
    usage
fi

# ---- Dependency check -------------------------------------------------------
check_tool() {
    if ! command -v "$1" &>/dev/null; then
        error "'$1' is not installed or not in PATH."
        exit 1
    fi
}

info "Checking prerequisites..."
check_tool amass
check_tool subfinder
check_tool httpx

# ---- Prepare output directory -----------------------------------------------
WORK_DIR="${OUTPUT_DIR}/${DOMAIN}_${TIMESTAMP}"
mkdir -p "${WORK_DIR}"
info "Results will be saved to: ${WORK_DIR}"

# ---- Step 1: Amass passive enumeration --------------------------------------
AMASS_OUT="${WORK_DIR}/amass_subs.txt"
info "Running amass passive enumeration on ${DOMAIN}..."
amass enum -passive -d "${DOMAIN}" -o "${AMASS_OUT}" 2>/dev/null || {
    warn "Amass finished with warnings. Partial results may be available."
}
AMASS_COUNT=$(wc -l < "${AMASS_OUT}" 2>/dev/null || echo 0)
info "Amass found ${AMASS_COUNT} subdomains."

# ---- Step 2: Subfinder enumeration ------------------------------------------
SUBFINDER_OUT="${WORK_DIR}/subfinder_subs.txt"
info "Running subfinder on ${DOMAIN}..."
subfinder -d "${DOMAIN}" -silent -o "${SUBFINDER_OUT}" 2>/dev/null || {
    warn "Subfinder finished with warnings."
}
SUBFINDER_COUNT=$(wc -l < "${SUBFINDER_OUT}" 2>/dev/null || echo 0)
info "Subfinder found ${SUBFINDER_COUNT} subdomains."

# ---- Step 3: Combine and deduplicate ----------------------------------------
COMBINED="${WORK_DIR}/all_subs_unique.txt"
info "Combining and deduplicating results..."
cat "${AMASS_OUT}" "${SUBFINDER_OUT}" 2>/dev/null \
    | tr '[:upper:]' '[:lower:]' \
    | sort -u \
    > "${COMBINED}"
COMBINED_COUNT=$(wc -l < "${COMBINED}")
info "Total unique subdomains: ${COMBINED_COUNT}"

# ---- Step 4: Probe live hosts with httpx ------------------------------------
HTTPX_OUT="${WORK_DIR}/live_hosts.txt"
info "Probing live hosts with httpx..."
httpx -l "${COMBINED}" -silent -status-code -title -tech-detect \
    -o "${HTTPX_OUT}" 2>/dev/null || {
    warn "httpx finished with warnings."
}
LIVE_COUNT=$(wc -l < "${HTTPX_OUT}" 2>/dev/null || echo 0)
info "Live hosts discovered: ${LIVE_COUNT}"

# ---- Step 5: Generate summary report ----------------------------------------
REPORT="${WORK_DIR}/summary_report.txt"
{
    echo "============================================================"
    echo "  Domain Reconnaissance Report"
    echo "  Target : ${DOMAIN}"
    echo "  Date   : $(date -u +"%Y-%m-%d %H:%M:%S UTC")"
    echo "============================================================"
    echo ""
    echo "--- Source Counts ---"
    echo "  Amass      : ${AMASS_COUNT}"
    echo "  Subfinder  : ${SUBFINDER_COUNT}"
    echo "  Combined   : ${COMBINED_COUNT} (deduplicated)"
    echo "  Live hosts : ${LIVE_COUNT}"
    echo ""
    echo "--- Files ---"
    echo "  ${AMASS_OUT}"
    echo "  ${SUBFINDER_OUT}"
    echo "  ${COMBINED}"
    echo "  ${HTTPX_OUT}"
    echo ""
    echo "--- Disclaimer ---"
    echo "  This report was generated for an authorized security assessment."
    echo "  Unauthorized use is prohibited and may violate applicable laws."
    echo "============================================================"
} > "${REPORT}"

info "Summary report saved to: ${REPORT}"
info "Reconnaissance complete for ${DOMAIN}."
