#!/usr/bin/env python3
"""
recon_script.py - OSINT Automation for Authorized Engagements

Educational OSINT automation script that combines subdomain enumeration,
email format validation, and technology fingerprinting using only public
APIs and passive reconnaissance techniques.

DISCLAIMER: This script is provided for AUTHORIZED SECURITY TESTING in
isolated lab environments only. Unauthorized reconnaissance against systems
you do not own or have explicit written permission to test is illegal.
Always obtain proper authorization before conducting any security assessment.

Usage:
    python3 recon_script.py -d example.com -o report.json
    python3 recon_script.py -d example.com --timeout 10 --rate-limit 2.0

Dependencies:
    pip install requests
"""

import argparse
import json
import logging
import re
import socket
import ssl
import sys
import time
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

try:
    import requests
except ImportError:
    print("[!] 'requests' library required: pip install requests")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
DEFAULT_TIMEOUT = 10          # HTTP timeout in seconds
DEFAULT_RATE_LIMIT = 1.5      # Minimum seconds between requests
USER_AGENT = "OSINT-Recon-Educational/1.0 (Authorized Security Assessment)"

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Rate Limiter
# ---------------------------------------------------------------------------
class RateLimiter:
    """Simple rate limiter that enforces a minimum delay between calls."""

    def __init__(self, min_interval: float = DEFAULT_RATE_LIMIT):
        self.min_interval = min_interval
        self._last_call: float = 0.0

    def wait(self) -> None:
        elapsed = time.time() - self._last_call
        if elapsed < self.min_interval:
            sleep_time = self.min_interval - elapsed
            logger.debug("Rate limiting: sleeping %.2f seconds", sleep_time)
            time.sleep(sleep_time)
        self._last_call = time.time()


# ---------------------------------------------------------------------------
# Subdomain Enumeration via crt.sh (Certificate Transparency)
# ---------------------------------------------------------------------------
def enumerate_subdomains_crtsh(domain: str, timeout: int, limiter: RateLimiter) -> list[str]:
    """
    Query crt.sh certificate transparency logs for subdomains.
    This is a fully passive technique -- no traffic touches the target.
    """
    url = "https://crt.sh/"
    params = {"q": f"%.{domain}", "output": "json"}
    subdomains: set[str] = set()

    logger.info("Querying crt.sh for subdomains of %s", domain)
    limiter.wait()

    try:
        resp = requests.get(url, params=params, timeout=timeout, headers={"User-Agent": USER_AGENT})
        resp.raise_for_status()
        entries = resp.json()

        for entry in entries:
            name_value = entry.get("name_value", "")
            # crt.sh may return newline-separated names in a single field
            for name in name_value.splitlines():
                name = name.strip().lower()
                # Remove wildcard prefix if present
                if name.startswith("*."):
                    name = name[2:]
                if name.endswith(domain):
                    subdomains.add(name)

        logger.info("Found %d unique subdomains via crt.sh", len(subdomains))

    except requests.exceptions.Timeout:
        logger.warning("crt.sh request timed out after %d seconds", timeout)
    except requests.exceptions.RequestException as exc:
        logger.error("crt.sh request failed: %s", exc)
    except (ValueError, KeyError) as exc:
        logger.error("Failed to parse crt.sh response: %s", exc)

    return sorted(subdomains)


# ---------------------------------------------------------------------------
# Email Format Validation
# ---------------------------------------------------------------------------
def validate_email_format(email: str) -> bool:
    """
    Validate that a string matches a standard email format.
    Uses RFC 5322 simplified pattern -- does NOT verify deliverability.
    """
    pattern = r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email))


def generate_email_formats(domain: str, first: str = "john", last: str = "doe") -> list[dict]:
    """
    Generate common corporate email format candidates for a domain.
    Returns a list of format patterns with example addresses.
    """
    formats = [
        {"pattern": "{first}.{last}",     "example": f"{first}.{last}@{domain}"},
        {"pattern": "{first}{last}",      "example": f"{first}{last}@{domain}"},
        {"pattern": "{f}{last}",          "example": f"{first[0]}{last}@{domain}"},
        {"pattern": "{first}_{last}",     "example": f"{first}_{last}@{domain}"},
        {"pattern": "{first}",            "example": f"{first}@{domain}"},
        {"pattern": "{last}.{first}",     "example": f"{last}.{first}@{domain}"},
        {"pattern": "{f}.{last}",         "example": f"{first[0]}.{last}@{domain}"},
    ]
    # Validate each generated example
    for fmt in formats:
        fmt["valid_format"] = validate_email_format(fmt["example"])
    return formats


# ---------------------------------------------------------------------------
# Technology Fingerprinting via HTTP Headers
# ---------------------------------------------------------------------------
def fingerprint_technology(url: str, timeout: int, limiter: RateLimiter) -> dict:
    """
    Identify technologies by inspecting HTTP response headers.
    Only sends a HEAD request to minimise footprint.
    """
    result: dict = {"url": url, "headers": {}, "technologies": []}
    limiter.wait()

    try:
        resp = requests.head(
            url,
            timeout=timeout,
            headers={"User-Agent": USER_AGENT},
            allow_redirects=True,
            verify=True,
        )
        result["status_code"] = resp.status_code
        result["headers"] = dict(resp.headers)

        # --- Header-based fingerprinting rules ---
        server = resp.headers.get("Server", "")
        if server:
            result["technologies"].append({"category": "Web Server", "value": server})

        powered_by = resp.headers.get("X-Powered-By", "")
        if powered_by:
            result["technologies"].append({"category": "Framework", "value": powered_by})

        if "X-AspNet-Version" in resp.headers:
            result["technologies"].append({"category": "Runtime", "value": f"ASP.NET {resp.headers['X-AspNet-Version']}"})

        if "X-Drupal-Cache" in resp.headers or "X-Generator" in resp.headers:
            gen = resp.headers.get("X-Generator", "Drupal (detected via cache header)")
            result["technologies"].append({"category": "CMS", "value": gen})

        if "X-Shopify-Stage" in resp.headers:
            result["technologies"].append({"category": "Platform", "value": "Shopify"})

        # Security headers audit
        security_headers = {
            "Strict-Transport-Security": "HSTS",
            "Content-Security-Policy": "CSP",
            "X-Content-Type-Options": "X-Content-Type-Options",
            "X-Frame-Options": "X-Frame-Options",
            "X-XSS-Protection": "X-XSS-Protection",
        }
        present = [name for hdr, name in security_headers.items() if hdr in resp.headers]
        missing = [name for hdr, name in security_headers.items() if hdr not in resp.headers]
        result["security_headers"] = {"present": present, "missing": missing}

        logger.info("Fingerprinted %s -- %d technologies identified", url, len(result["technologies"]))

    except requests.exceptions.RequestException as exc:
        logger.warning("Fingerprinting failed for %s: %s", url, exc)
        result["error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# Report Generation
# ---------------------------------------------------------------------------
def build_report(domain: str, subdomains: list, emails: list, fingerprints: list) -> dict:
    """Assemble all findings into a structured JSON report."""
    return {
        "meta": {
            "tool": "recon_script.py",
            "version": "1.0",
            "target_domain": domain,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "disclaimer": "Authorized security assessment only. Do not use without permission.",
        },
        "subdomains": {
            "source": "crt.sh (Certificate Transparency)",
            "count": len(subdomains),
            "results": subdomains,
        },
        "email_formats": emails,
        "technology_fingerprints": fingerprints,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="OSINT Automation Script -- Authorized Engagements Only",
    )
    parser.add_argument("-d", "--domain", required=True, help="Target domain (e.g. example.com)")
    parser.add_argument("-o", "--output", default=None, help="Output JSON file path")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="HTTP timeout in seconds")
    parser.add_argument("--rate-limit", type=float, default=DEFAULT_RATE_LIMIT, help="Seconds between requests")
    args = parser.parse_args()

    domain = args.domain.lower().strip()
    limiter = RateLimiter(min_interval=args.rate_limit)

    logger.info("Starting OSINT recon for: %s", domain)

    # 1. Subdomain enumeration
    subdomains = enumerate_subdomains_crtsh(domain, args.timeout, limiter)

    # 2. Email format generation
    email_formats = generate_email_formats(domain)

    # 3. Technology fingerprinting (top-level domain only to stay passive)
    fingerprints = []
    for scheme in ("https", "http"):
        url = f"{scheme}://{domain}"
        fp = fingerprint_technology(url, args.timeout, limiter)
        fingerprints.append(fp)

    # 4. Build and output report
    report = build_report(domain, subdomains, email_formats, fingerprints)
    report_json = json.dumps(report, indent=2, default=str)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(report_json)
        logger.info("Report written to %s", args.output)
    else:
        print(report_json)

    logger.info("Recon complete. %d subdomains, %d email formats, %d fingerprints.",
                len(subdomains), len(email_formats), len(fingerprints))


if __name__ == "__main__":
    main()
