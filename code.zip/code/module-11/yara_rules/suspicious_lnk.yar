/*
 * =============================================================================
 * YARA Rule: Suspicious LNK File Detection
 * =============================================================================
 * EDUCATIONAL PURPOSE ONLY - For authorized security analysis in lab environments.
 *
 * Detects Windows shortcut (LNK) files containing references to command
 * interpreters, encoded commands, or known payload delivery arguments.
 * Malicious LNK files are commonly used as initial access vectors.
 * =============================================================================
 */

rule Suspicious_LNK_Command_Execution
{
    meta:
        description = "Detects LNK files referencing command interpreters with suspicious arguments"
        author = "Security Course Lab"
        date = "2025-01-15"
        reference = "https://attack.mitre.org/techniques/T1204/002/"
        severity = "high"

    strings:
        // LNK file magic bytes (Windows Shell Link)
        $lnk_magic = { 4C 00 00 00 01 14 02 00 }

        // Command interpreter references (wide strings for LNK internal format)
        $cmd        = "cmd.exe" ascii wide nocase
        $powershell = "powershell" ascii wide nocase
        $pwsh       = "pwsh.exe" ascii wide nocase
        $mshta      = "mshta.exe" ascii wide nocase
        $wscript    = "wscript.exe" ascii wide nocase
        $cscript    = "cscript.exe" ascii wide nocase
        $rundll32   = "rundll32.exe" ascii wide nocase

        // Suspicious argument patterns
        $enc_cmd    = "-encodedcommand" ascii wide nocase
        $enc_short  = " -enc " ascii wide nocase
        $hidden     = "-windowstyle hidden" ascii wide nocase
        $hidden2    = "-w hidden" ascii wide nocase
        $bypass     = "-executionpolicy bypass" ascii wide nocase
        $bypass2    = "-ep bypass" ascii wide nocase
        $noprofile  = "-noprofile" ascii wide nocase
        $invoke     = "Invoke-Expression" ascii wide nocase
        $iex        = "IEX" ascii wide
        $download   = "DownloadString" ascii wide nocase
        $webclient  = "Net.WebClient" ascii wide nocase
        $certutil   = "certutil" ascii wide nocase
        $bitsadmin  = "bitsadmin" ascii wide nocase

    condition:
        $lnk_magic at 0 and
        (
            // LNK spawning PowerShell with evasion flags
            (($powershell or $pwsh) and ($enc_cmd or $enc_short or $hidden or $hidden2 or $bypass or $bypass2)) or
            // LNK with download cradle patterns
            (($invoke or $iex) and ($download or $webclient)) or
            // LNK using LOLBins for payload delivery
            (($certutil or $bitsadmin) and ($cmd or $powershell)) or
            // LNK executing mshta/wscript/rundll32 (common for script-based payloads)
            ($mshta and ($cmd or $powershell)) or
            ($rundll32 and $hidden)
        )
}
