/*
 * =============================================================================
 * YARA Rule: HTML Smuggling Detection
 * =============================================================================
 * EDUCATIONAL PURPOSE ONLY - For authorized security analysis in lab environments.
 *
 * Detects HTML files containing patterns associated with HTML smuggling,
 * where JavaScript assembles a malicious payload client-side using Blob
 * objects, base64 decoding, or data URIs to bypass network inspection.
 * =============================================================================
 */

rule HTML_Smuggling_Blob_Download
{
    meta:
        description = "Detects HTML files using Blob/createObjectURL for file smuggling"
        author = "Security Course Lab"
        date = "2025-01-15"
        reference = "https://attack.mitre.org/techniques/T1027/006/"
        severity = "high"

    strings:
        $blob       = "new Blob(" ascii nocase
        $create_url = "createObjectURL" ascii nocase
        $download1  = ".download" ascii nocase
        $download2  = "msSaveBlob" ascii nocase
        $click      = ".click()" ascii

        $base64_1   = "atob(" ascii
        $base64_2   = "btoa(" ascii
        $base64_3   = "base64" ascii nocase
        $base64_4   = "charCodeAt" ascii

        $mime_zip   = "application/zip" ascii nocase
        $mime_octet = "application/octet-stream" ascii nocase
        $mime_iso   = "application/x-iso" ascii nocase

    condition:
        filesize < 5MB and
        (
            // Pattern 1: Blob creation + download trigger
            ($blob and $create_url and ($download1 or $download2) and $click) or
            // Pattern 2: Base64 decode + Blob + suspicious MIME type
            (($base64_1 or $base64_3) and $blob and ($mime_zip or $mime_octet or $mime_iso)) or
            // Pattern 3: charCodeAt with Blob (byte array assembly)
            ($base64_4 and $blob and $create_url and ($download1 or $download2))
        )
}

rule HTML_Smuggling_Large_Encoded_Payload
{
    meta:
        description = "Detects HTML files with large base64 or hex-encoded payloads"
        author = "Security Course Lab"
        date = "2025-01-15"
        reference = "https://attack.mitre.org/techniques/T1027/006/"
        severity = "medium"

    strings:
        $html_tag   = "<html" ascii nocase
        $script_tag = "<script" ascii nocase

        // Large base64 string assigned to a variable (100+ chars of base64)
        $b64_var = /var\s+\w+\s*=\s*["'][A-Za-z0-9+\/=]{100,}["']/ ascii

        // Hex-encoded byte array pattern
        $hex_array = /\[0x[0-9a-fA-F]{2}(,\s*0x[0-9a-fA-F]{2}){20,}\]/ ascii

    condition:
        filesize < 10MB and
        $html_tag and $script_tag and
        ($b64_var or $hex_array)
}
