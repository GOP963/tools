#!/usr/bin/env bash
# =============================================================================
# metadata_scrubber.sh - Metadata Scrubbing Automation Script
# =============================================================================
# EDUCATIONAL PURPOSE ONLY - For use in authorized red team lab environments.
# Strips metadata from documents and images to prevent information leakage
# during authorized engagements.
#
# Dependencies: exiftool (libimage-exiftool-perl)
# Usage: ./metadata_scrubber.sh <file_or_directory>
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

SUPPORTED_EXTENSIONS="pdf|docx|doc|xlsx|xls|pptx|ppt|jpg|jpeg|png|gif|bmp|tiff|svg"

log_info()  { echo -e "${GREEN}[+]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
log_error() { echo -e "${RED}[-]${NC} $1"; }

if ! command -v exiftool &> /dev/null; then
    log_error "exiftool is not installed. Install with: sudo apt install libimage-exiftool-perl"
    exit 1
fi

if [ $# -lt 1 ]; then
    echo "Usage: $0 <file_or_directory>"
    echo "Strips metadata from documents and images."
    exit 1
fi

TARGET="$1"
SCRUBBED=0
FAILED=0

scrub_file() {
    local filepath="$1"
    local extension="${filepath##*.}"
    extension=$(echo "$extension" | tr '[:upper:]' '[:lower:]')

    if ! echo "$extension" | grep -qiE "^($SUPPORTED_EXTENSIONS)$"; then
        log_warn "Skipping unsupported file type: $filepath"
        return
    fi

    log_info "Scrubbing metadata from: $filepath"

    if exiftool -all= -overwrite_original "$filepath" 2>/dev/null; then
        # Verification step: confirm metadata was removed
        remaining=$(exiftool -s -s -s -all "$filepath" 2>/dev/null | wc -l)
        if [ "$remaining" -le 2 ]; then
            log_info "Verified clean: $filepath (residual tags: $remaining)"
            SCRUBBED=$((SCRUBBED + 1))
        else
            log_warn "Partial scrub: $filepath ($remaining tags remain -- may be structural)"
            SCRUBBED=$((SCRUBBED + 1))
        fi
    else
        log_error "Failed to scrub: $filepath"
        FAILED=$((FAILED + 1))
    fi
}

if [ -f "$TARGET" ]; then
    scrub_file "$TARGET"
elif [ -d "$TARGET" ]; then
    log_info "Scanning directory: $TARGET"
    while IFS= read -r -d '' file; do
        scrub_file "$file"
    done < <(find "$TARGET" -type f -regextype posix-extended \
        -iregex ".*\.($SUPPORTED_EXTENSIONS)" -print0 2>/dev/null)
else
    log_error "Target not found: $TARGET"
    exit 1
fi

echo ""
echo "========================================="
echo " Metadata Scrubbing Complete"
echo " Files scrubbed : $SCRUBBED"
echo " Failures       : $FAILED"
echo "========================================="
